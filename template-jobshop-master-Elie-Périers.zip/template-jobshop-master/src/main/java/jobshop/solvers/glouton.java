package jobshop.solvers;

import jobshop.Instance;
import jobshop.Main;
import jobshop.Result;
import jobshop.Solver;
import jobshop.encodings.ResourceOrder;
import jobshop.encodings.Task;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class glouton implements Solver {

	// SPT = 0
	// LPT = 1
	// LRPT = 2
	public int PriorityRule = 0 ; 
	
	
	
	
	@Override
	public Result solve(Instance instance, long deadline) {
		
		ResourceOrder sol =  new ResourceOrder(instance);
		
		//On garde en mémoire les taches déjà effectuées dans un tableau, on instancie à 0 et on passe à 1 quand on rencontré la tache
		int [][] scheduled = new int [instance.numJobs] [instance.numTasks] ; 
		Task t = nextToSchedule (instance, scheduled) ;
		
		while (t != null) {
			
			int m = instance.machine(t);
			sol.tasksByMachine[m][sol.nextFreeSlot[m]++] = t ;
			scheduled[t.job][t.task] = 1 ;
			t = nextToSchedule (instance, scheduled) ;
		}
		
		
		
		
		return new Result(instance, sol.toSchedule(), Result.ExitCause.Blocked) ;
	}
	
	
	
	public Task nextToSchedule (Instance instance, int [][] scheduled) {
		Task next = null ;
		//liste des taches à trier
    	ArrayList<Task> dispo = new ArrayList<Task>();
    	
		//pour chaque job, on ajoute la prochaine tache a executer
    	for(int j = 0 ; j<instance.numJobs ; j++) {
            for(int t = 0 ; t<instance.numTasks ; t++) {
            	if(scheduled[j][t] == 0) {
            		dispo.add(new Task(j,t));
            		break;
            	}
            }   
    	}
		if (dispo.isEmpty()) {
			return null ;
		}
		//tri SPT, plus petite durée
		if(PriorityRule == 0) {
			next = Collections.min(dispo, (a,b)->Integer.compare(instance.duration(a.job, a.task), instance.duration(b.job, b.task)));
		} 
		//tri LPT, plus grande durée
		else if (PriorityRule == 1) {
			next = Collections.max(dispo, (a,b)->Integer.compare(instance.duration(a.job, a.task), instance.duration(b.job, b.task)));

		} 
		//tri LRPT, donne la priorité à la tâche appartenant au job ayant la plus grande durée
		else if (PriorityRule == 2) {
			Comparator<Task> comparateur = new Comparator<Task>() {
    			public int compare(Task a, Task b) {
    				int resta = 0;
        			for(int i = a.task ; i<= instance.numTasks; i++) {
        				resta += instance.duration(a.job, a.task);
        			}
        			
        			int restb = 0;
        			for(int i = b.task ; i<= instance.numTasks; i++) {
        				restb += instance.duration(b.job, b.task);
        			}
        			
        			return Integer.compare(resta, restb);
    		}};
    		next = Collections.max(dispo, comparateur);
			
			
		}
		return next ;
	}

}
