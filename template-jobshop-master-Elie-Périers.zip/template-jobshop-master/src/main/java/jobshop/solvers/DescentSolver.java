package jobshop.solvers;

import jobshop.Instance;
import jobshop.Result;
import jobshop.Schedule;
import jobshop.Solver;
import jobshop.encodings.ResourceOrder;
import jobshop.encodings.Task;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DescentSolver implements Solver {

    /** A block represents a subsequence of the critical path such that all tasks in it execute on the same machine.
     * This class identifies a block in a ResourceOrder representation.
     *
     * Consider the solution in ResourceOrder representation
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (0,2) (2,1) (1,1)
     * machine 2 : ...
     *
     * The block with : machine = 1, firstTask= 0 and lastTask = 1
     * Represent the task sequence : [(0,2) (2,1)]
     *
     * */
    static class Block {
        /** machine on which the block is identified */
        final int machine;
        /** index of the first task of the block */
        final int firstTask;
        /** index of the last task of the block */
        final int lastTask;

        Block(int machine, int firstTask, int lastTask) {
            this.machine = machine;
            this.firstTask = firstTask;
            this.lastTask = lastTask;
        }
    }

    /**
     * Represents a swap of two tasks on the same machine in a ResourceOrder encoding.
     *
     * Consider the solution in ResourceOrder representation
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (0,2) (2,1) (1,1)
     * machine 2 : ...
     *
     * The swam with : machine = 1, a= 0 and b = 1
     * Represent inversion of the two tasks : (0,2) and (2,1)
     * Applying this swap on the above resource order should result in the following one :
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (2,1) (0,2) (1,1)
     * machine 2 : ...
     */
    static class Swap {
        // machine on which to perform the swap
        final int machine;
        // index of one task to be swapped
        final int t1;
        // index of the other task to be swapped
        final int t2;

        Swap(int machine, int a, int b) {
            this.machine = machine;
            this.t1 = a;
            this.t2 = b;
        }

        /** Apply this swap on the given resource order, transforming it into a new solution. */
        public void applyOn(ResourceOrder order) {
            Task t = order.tasksByMachine[this.machine][t1];
            order.tasksByMachine[this.machine][t1] = order.tasksByMachine[this.machine][t2];
            order.tasksByMachine[this.machine][t2] = t;
        }
    }

  
   
    @Override
    public Result solve(final Instance instance, final long deadline) {
        Solver sol = new glouton();
        ResourceOrder order = new ResourceOrder(sol.solve(instance, deadline).schedule);

        ResourceOrder orderTest;
        int Makespantest, bestMakespan = order.toSchedule().makespan();

        boolean update = true;
        while (update &&  (deadline > System.currentTimeMillis())) {
            update = false;
            for (Block block : blocksOfCriticalPath(order)) {
                for (Swap swap : neighbors(block)) {
                    orderTest = order.copy();
                    swap.applyOn(orderTest);
                    Makespantest = orderTest.toSchedule().makespan();
                    if (Makespantest < bestMakespan) {
                        order = orderTest.copy();
                        bestMakespan = Makespantest;
                        update = true; 
                    }
                }
            }
        }
        if (deadline - System.currentTimeMillis() < 1) {
            return new Result(instance, order.toSchedule(), Result.ExitCause.Timeout);
        }else {
            return new Result(instance, order.toSchedule(), Result.ExitCause.ProvedOptimal);
        }
    }
    
    
    
    
    
    
    
    
    /** Returns a list of all blocks of the critical path. */
    List<Block> blocksOfCriticalPath(ResourceOrder order) {
    	List<Block> blocks = new ArrayList<Block>();
    	List<Task> criticalKush = order.toSchedule().criticalPath();
    	
    	int a = 0;
        int b = 1;
        // on remplit blocks jusqu'à ce que b soit égal au nombre des taches de départ
        while(b < criticalKush.size()-1) {
        	//recuperation de la machine
        	int m = order.instance.machine(criticalKush.get(a));
        	while(order.instance.machine(criticalKush.get(b)) == m && b < criticalKush.size()-1) {
        		b++;
        	}
        	
        	if(b-1 > a) {
        		List<Task> l = Arrays.asList(order.tasksByMachine[m]);
        		blocks.add(new Block(m, l.indexOf(criticalKush.get(a)) ,l.indexOf(criticalKush.get(b-1)) ));
        	}
        	a = b; 
        	b++;
        }
        
        
        return blocks;
    }

    /** For a given block, return the possible swaps for the Nowicki and Smutnicki neighborhood */
    List<Swap> neighbors(Block block) {
    	//initialisation d'une liste de swapq
    	List<Swap> swapl = new ArrayList<Swap>();
    	
    	//si il n'y a que 2 blocks (le minimum), on réalise un simple swap : 
    	if (block.firstTask + 1 == block.lastTask) {
    		swapl.add(new Swap(block.machine, block.firstTask, block.lastTask));
    	}
    	//sinon, on échange les 2 premiers et les 2 derniers : 
    	else { //block de taille > 2 => 2 swaps
        	swapl.add(new Swap(block.machine, block.firstTask, block.firstTask +1));
        	swapl.add(new Swap(block.machine, block.lastTask-1, block.lastTask));
        }
    	
    return swapl ;
    }

}
