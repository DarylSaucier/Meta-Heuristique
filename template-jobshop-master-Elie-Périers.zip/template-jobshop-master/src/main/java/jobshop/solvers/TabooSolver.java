package jobshop.solvers;

import jobshop.Instance;
import jobshop.Result;
import jobshop.Schedule;
import jobshop.Solver;
import jobshop.encodings.ResourceOrder;
import jobshop.encodings.Task;
import jobshop.solvers.DescentSolver.Block;
import jobshop.solvers.DescentSolver.Swap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TabooSolver implements Solver {

	private int maxIter, dureeTabou ;

    public TabooSolver(int maxIter, int dureeTabou){
        super();
        this.maxIter = maxIter;
        this.dureeTabou = dureeTabou;
    }
    
    static class Block {
        /** machine on which the block is identified */
        final int machine;
        /** index of the first task of the block */
        final int firstTask;
        /** index of the last task of the block */
        final int lastTask;

        Block(int machine, int firstTask, int lastTask) {
            this.machine = machine;
            this.firstTask = firstTask;
            this.lastTask = lastTask;
        }
    }
    
    /**
     * Represents a swap of two tasks on the same machine in a ResourceOrder encoding.
     *
     * Consider the solution in ResourceOrder representation
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (0,2) (2,1) (1,1)
     * machine 2 : ...
     *
     * The swam with : machine = 1, a= 0 and b = 1
     * Represent inversion of the two tasks : (0,2) and (2,1)
     * Applying this swap on the above resource order should result in the following one :
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (2,1) (0,2) (1,1)
     * machine 2 : ...
     */
    static class Swap {
        // machine on which to perform the swap
        final int machine;
        // index of one task to be swapped
        final int t1;
        // index of the other task to be swapped
        final int t2;

        Swap(int machine, int a, int b) {
            this.machine = machine;
            this.t1 = a;
            this.t2 = b;
        }

        /** Apply this swap on the given resource order, transforming it into a new solution. */
        /** Upgraded to return the couple of switched task for taboo */
        int[] applyOn(ResourceOrder order) {
            int[] t1t2 = new int[2];
            t1t2[0] = order.tasksByMachine[machine][t1].task + order.instance.numTasks * order.tasksByMachine[machine][t1].job;
            t1t2[1] = order.tasksByMachine[machine][t2].task + order.instance.numTasks * order.tasksByMachine[machine][t2].job;
            Task task1 = order.tasksByMachine[machine][t1];
            Task task2 = order.tasksByMachine[machine][t2];
            order.tasksByMachine[machine][t1] = task2;
            order.tasksByMachine[machine][t2] = task1;
            return t1t2;
        }
    }
    
    
   
	@Override
	public Result solve(Instance instance, long deadline) {
		Solver greedy = new glouton();

        // solStart = s*, sCurrent = s, sPrime = s', sSeconde = s'', correspondance page 10 du sujet
        ResourceOrder solStart = new ResourceOrder(greedy.solve(instance, deadline).schedule);//sInit
        ResourceOrder sCurrent = solStart.copy(), sPrime = sCurrent.copy(), sSeconde;
        int starMakespan = solStart.toSchedule().makespan();
        int primeMakespan, secondeMakespan;
        //on initialise aussi les entiers qui vont servir à comparer les makespan

      // Acces au tabou
        int[] swapedTaskSeconde;
        int[] swapedTaskPrime = new int[2];
        
        // sTaboo Def & Init : creation de la matrice
        int nbTaskTotal = instance.numJobs*instance.numTasks;
        int[][] sTaboo= new int[nbTaskTotal][nbTaskTotal];
        // On initialise la matrice à 0 partout
        for (int i = 0; i < nbTaskTotal;i++){
            for (int j = 0; i < nbTaskTotal;i++){
                sTaboo[i][j]=0;
            }
        }
        
        // init des variables de la boucle
        boolean updated;
        int k =0;
        
        // debut de la boucle
        while (k < this.maxIter &&  (deadline - System.currentTimeMillis() > 1)) {
        	//etape 1
            k++;
            updated = false;
            primeMakespan = 1000000000; // on initialise la premiere durée très grande pour trouver mieux dès la première itération
            sCurrent = sPrime.copy();
            // choix du meilleur voisin s' non tabou :
            for (Block block : blocksOfCriticalPath(sCurrent)) {
                for (Swap swap : neighbors(block)) {
                    sSeconde = sCurrent.copy();
                    swapedTaskSeconde = swap.applyOn(sSeconde);
                    secondeMakespan = sSeconde.toSchedule().makespan();
                    // vérification du caractère tabou de la solution, si la permutation est autorisée
                    if (sTaboo[swapedTaskSeconde[0]][swapedTaskSeconde[1]] < k) {
                        updated = true;
                        // On regarde si s' meilleur que s*
                        if (secondeMakespan < primeMakespan) {
                            swapedTaskPrime = swapedTaskSeconde;
                            primeMakespan = secondeMakespan;
                            sPrime = sSeconde.copy();
                        }
                    }
                }
            }
            if (updated) {
            	//on note dans la matrice le numéro d'itération à partir de laquelle on pourra réexaminer la solution
                sTaboo[swapedTaskPrime[1]][swapedTaskPrime[0]] = k + this.dureeTabou;
                if (primeMakespan < starMakespan) {
                    solStart = sPrime.copy();
                    starMakespan = primeMakespan;
                }
            }
        }
        if (deadline - System.currentTimeMillis() < 1) {
            return new Result(instance, solStart.toSchedule(), Result.ExitCause.Timeout);
        }else if(k >= maxIter) {
            return new Result(instance, solStart.toSchedule(), Result.ExitCause.Blocked);
        }else{
            return new Result(instance, solStart.toSchedule(), Result.ExitCause.ProvedOptimal);
        }
		
		
	}
	
	
	
	
	/** Returns a list of all blocks of the critical path. */
    List<Block> blocksOfCriticalPath(ResourceOrder order) {
    	List<Block> blocks = new ArrayList<Block>();
    	List<Task> criticalKush = order.toSchedule().criticalPath();
    	
    	int a = 0;
        int b = 1;
        // on remplit blocks jusqu'à ce que b soit égal au nombre des taches de départ
        while(b < criticalKush.size()-1) {
        	//recuperation de la machine
        	int m = order.instance.machine(criticalKush.get(a));
        	while(order.instance.machine(criticalKush.get(b)) == m && b < criticalKush.size()-1) {
        		b++;
        	}
        	
        	if(b-1 > a) {
        		List<Task> l = Arrays.asList(order.tasksByMachine[m]);
        		blocks.add(new Block(m, l.indexOf(criticalKush.get(a)) ,l.indexOf(criticalKush.get(b-1)) ));
        	}
        	a = b; 
        	b++;
        }
        
        
        return blocks;
    }

    /** For a given block, return the possible swaps for the Nowicki and Smutnicki neighborhood */
    List<Swap> neighbors(Block block) {
    	//initialisation d'une liste de swapq
    	List<Swap> swapl = new ArrayList<Swap>();
    	
    	//si il n'y a que 2 blocks (le minimum), on réalise un simple swap : 
    	if (block.firstTask + 1 == block.lastTask) {
    		swapl.add(new Swap(block.machine, block.firstTask, block.lastTask));
    	}
    	//sinon, on échange les 2 premiers et les 2 derniers : 
    	else { //block de taille > 2 => 2 swaps
        	swapl.add(new Swap(block.machine, block.firstTask, block.firstTask +1));
        	swapl.add(new Swap(block.machine, block.lastTask-1, block.lastTask));
        }
    	
    return swapl ;
    }

}


